# Rental-system
Project “E-Home solution” is complete web based application using laravel framework. The 
main aim of the project is to develop a web application for the facilitation owner and tenant 
through property advisor regarding their properties. Tenant search property according to his 
desire and budget. This system will provide a very ease for the users to search or advertise their 
property for rent.
