<?php

use Illuminate\Database\Seeder;
use \App\RegisterAdmin;
class AdminTableSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    
    public function run()
    {
        $this->detail_1();
       
        
    }
    
  

    public function detail_3() {
        $reg_admin = new RegisterAdmin;
        $reg_admin ->first_name = 'karasisi';
        $reg_admin ->last_name = 'tro';
        $reg_admin ->phone = '86754';
        $reg_admin ->address = 'Kigali';
        $reg_admin ->user_id_fk = '1'; 
        $reg_admin->save();
    }
}
