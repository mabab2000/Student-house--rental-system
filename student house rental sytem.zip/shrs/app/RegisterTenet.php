<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class RegisterTenet extends Model
{
    //
}
